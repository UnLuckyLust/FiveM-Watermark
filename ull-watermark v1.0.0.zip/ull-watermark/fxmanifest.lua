fx_version 'adamant'
game 'gta5'
lua54 'yes'

author 'UnLuckyLust#9534'
description 'WaterMark for FiveM servers'
version '1.0.0'

ui_page '/nui.html'

files {
    '/nui.html',
    '/style.css',
    '/logo.png',
}