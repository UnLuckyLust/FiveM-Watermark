# WaterMark for FiveM Servers UnLuckyLust#9534
# For support join us on Discord: https://discord.gg/gtH9nkGrHu

# installation
1. ensure ull-watermark
2. change the config in 'nui.html' however you want